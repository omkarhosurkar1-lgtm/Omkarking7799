"""
Naye passwords banata hai aur index.html mein wahi badal deta hai.

Chalane ka tarika (computer ya Termux par):
    python change_passwords.py

Phir jo 3 lines print hon, unhe Railway -> Variables mein daal dein
(PASS_1MONTH, PASS_3MONTH, PASS_LIFETIME) aur updated index.html ko website par dobara upload karein.
"""
import re, secrets, string

FILE = "index.html"
ALPHA = string.ascii_uppercase + string.digits
new = lambda tag: f"{tag}-" + "".join(secrets.choice(ALPHA) for _ in range(8))

pw = {"1month": new("M1"), "3month": new("M3"), "lifetime": new("LT")}
html = open(FILE, encoding="utf-8").read()
for plan, value in pw.items():
    html, n = re.subn(r'"[^"]+"(\s*:\s*\{\s*plan:\s*"%s")' % plan, '"%s"\\1' % value, html)
    assert n == 1, f"{plan} wali line index.html mein nahi mili"
open(FILE, "w", encoding="utf-8").write(html)

print("index.html update ho gaya. Ab ye Railway Variables mein daalein:\n")
print(f"PASS_1MONTH={pw['1month']}")
print(f"PASS_3MONTH={pw['3month']}")
print(f"PASS_LIFETIME={pw['lifetime']}")
