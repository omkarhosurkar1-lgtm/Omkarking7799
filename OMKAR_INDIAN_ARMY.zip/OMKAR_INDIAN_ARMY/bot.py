# OMKAR INDIAN ARMY - Telegram Bot
# Passwords yahan wahi hain jo index.html (PLANS) mein hain, taaki bot ka diya password website par chale.
import os, io, threading
from urllib.parse import quote

import telebot
from telebot import types
import qrcode

# ---------- Railway Variables se aate hain (token kabhi code mein na likhein) ----------
BOT_TOKEN     = os.environ["BOT_TOKEN"]
ADMIN_CHAT_ID = int(os.environ.get("ADMIN_CHAT_ID", "8144077984"))
UPI_ID        = os.environ.get("UPI_ID", "8971050522@ybl")

TG_LINK      = "https://t.me/OMKAR_INDIAN_ARMY_35_BOT"
WA_LINK      = "https://chat.whatsapp.com/LNAeWXwMLSt1JdpEM0S8vG?s=cl&p=a&mlu=4&ilr=4"
SUPPORT_LINK = "https://t.me/Problemsolvegroup_33"

PLANS = {
    "1m":   {"name": "1 Month Plan",            "price": 49,  "days": "30 din"},
    "3m":   {"name": "3 Months Plan",           "price": 115, "days": "90 din"},
    "life": {"name": "Permanent Lifetime Plan", "price": 500, "days": "kabhi khatam nahi"},
}

# index.html ke PLANS wale passwords (default). Badalne ke liye change_passwords.py chalayein.
PASSWORDS = {
    "1m":   os.environ.get("PASS_1MONTH",   "PASS_1MONTH_123"),
    "3m":   os.environ.get("PASS_3MONTH",   "PASS_3MONTH_456"),
    "life": os.environ.get("PASS_LIFETIME", "PASS_LIFETIME_789"),
}

bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML")
waiting_for_ss = {}   # user_id -> plan code

# ---------- Keyboards ----------
def main_keyboard():
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    kb.add(types.KeyboardButton("📋 Plans"), types.KeyboardButton("🔴 HELP"))
    return kb

def plans_keyboard():
    kb = types.InlineKeyboardMarkup(row_width=1)
    for code, p in PLANS.items():
        kb.add(types.InlineKeyboardButton(f"💎 {p['name']} - ₹{p['price']}", callback_data=f"buy|{code}"))
    kb.add(types.InlineKeyboardButton("🔴 HELP", callback_data="help"))
    return kb

def help_keyboard():
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton("📢 Telegram Channel", url=TG_LINK),
        types.InlineKeyboardButton("💬 WhatsApp Group", url=WA_LINK),
        types.InlineKeyboardButton("🆘 Support Group", url=SUPPORT_LINK),
        types.InlineKeyboardButton("📋 Plans Dekhein", callback_data="plans"),
    )
    return kb

# ---------- Messages ----------
def send_plans(chat_id):
    text = "💎 <b>OMKAR INDIAN ARMY - VIP PLANS</b>\n\n"
    for p in PLANS.values():
        text += f"✅ {p['name']} — <b>₹{p['price']}</b> ({p['days']})\n"
    text += "\n👇 Apna plan chunein:"
    bot.send_message(chat_id, text, reply_markup=plans_keyboard())

def send_help(chat_id):
    text = ("🔴 <b>HELP</b>\n\n"
            "1️⃣ /start dabayein aur plan chunein\n"
            "2️⃣ QR scan karke ya UPI ID par payment karein\n"
            "3️⃣ <b>Payment Kar Diya</b> dabayein aur screenshot bhejein\n"
            "4️⃣ Verify hote hi aapko password mil jayega\n"
            "5️⃣ Password website mein daal kar sab bhaag unlock karein\n\n"
            "Neeche diye links se judein 👇")
    bot.send_message(chat_id, text, reply_markup=help_keyboard())

def _safe_delete(chat_id, message_id):
    try:
        bot.delete_message(chat_id, message_id)
    except Exception as e:
        print("Delete failed:", e)

# ---------- Commands ----------
@bot.message_handler(commands=["start"])
def start(message):
    bot.send_message(message.chat.id,
                     "🙏 <b>Welcome to OMKAR INDIAN ARMY!</b>\n\nNeeche sabhi plans diye gaye hain.",
                     reply_markup=main_keyboard())
    send_plans(message.chat.id)

@bot.message_handler(commands=["help"])
def help_cmd(message):
    send_help(message.chat.id)

@bot.message_handler(func=lambda m: m.text in ("📋 Plans", "🔴 HELP"))
def keyboard_buttons(message):
    send_plans(message.chat.id) if message.text == "📋 Plans" else send_help(message.chat.id)

# ---------- Button clicks ----------
@bot.callback_query_handler(func=lambda call: True)
def callbacks(call):
    chat_id = call.message.chat.id
    parts = call.data.split("|")
    action = parts[0]

    if action == "help":
        bot.answer_callback_query(call.id); send_help(chat_id)

    elif action == "plans":
        bot.answer_callback_query(call.id); send_plans(chat_id)

    elif action == "buy" and parts[1] in PLANS:
        code = parts[1]; plan = PLANS[code]
        bot.answer_callback_query(call.id)
        upi_url = f"upi://pay?pa={UPI_ID}&pn={quote('Omkar Indian Army')}&am={plan['price']}&cu=INR"
        buf = io.BytesIO(); qrcode.make(upi_url).save(buf, format="PNG"); buf.seek(0)
        caption = (f"✅ Aapne chuna: <b>{plan['name']}</b>\n\n"
                   f"📲 QR scan karein ya is UPI ID par pay karein:\n<code>{UPI_ID}</code>\n"
                   f"💰 Amount: <b>₹{plan['price']}</b>\n\n"
                   f"Payment ke baad <b>Payment Kar Diya</b> dabayein.")
        kb = types.InlineKeyboardMarkup(row_width=1)
        kb.add(types.InlineKeyboardButton("✅ Payment Kar Diya", callback_data=f"paid|{code}"),
               types.InlineKeyboardButton("🔴 HELP", callback_data="help"))
        bot.send_photo(chat_id, buf, caption=caption, reply_markup=kb)

    elif action == "paid" and parts[1] in PLANS:
        waiting_for_ss[chat_id] = parts[1]
        bot.answer_callback_query(call.id)
        bot.send_message(chat_id, "📸 <b>Ab apne payment ka screenshot bhejein.</b>")

    elif action in ("ap", "rj"):
        if call.from_user.id != ADMIN_CHAT_ID:
            bot.answer_callback_query(call.id, "Sirf admin ke liye", show_alert=True); return
        user_id, code = int(parts[1]), parts[2]
        if action == "ap":
            bot.answer_callback_query(call.id, "Approved!")
            try: bot.edit_message_caption("✅ Approved", chat_id=chat_id, message_id=call.message.message_id)
            except Exception: pass
            sent = bot.send_message(user_id,
                f"✅ <b>Payment Verified!</b>\n\n🔑 Aapka File Password:\n<code>{PASSWORDS[code]}</code>\n\n"
                f"⚠️ Ye message 5 minute baad delete ho jayega. Password abhi copy kar lein.")
            threading.Timer(300, _safe_delete, args=(user_id, sent.message_id)).start()
        else:
            bot.answer_callback_query(call.id, "Rejected!")
            try: bot.edit_message_caption("❌ Rejected", chat_id=chat_id, message_id=call.message.message_id)
            except Exception: pass
            bot.send_message(user_id, "❌ <b>Payment verify nahi hua.</b>\nSahi screenshot dobara bhejein ya HELP dabayein.")

# ---------- Screenshot ----------
@bot.message_handler(content_types=["photo"])
def screenshot(message):
    uid = message.chat.id
    code = waiting_for_ss.pop(uid, None)
    if not code:
        bot.send_message(uid, "Pehle /start dabakar plan chunein, phir screenshot bhejein."); return
    bot.send_message(uid, "⏳ <b>Screenshot admin ko bhej diya gaya hai.</b> Verification ka intezar karein.")
    kb = types.InlineKeyboardMarkup()
    kb.add(types.InlineKeyboardButton("✅ Approve", callback_data=f"ap|{uid}|{code}"),
           types.InlineKeyboardButton("❌ Reject",  callback_data=f"rj|{uid}|{code}"))
    p = PLANS[code]
    bot.send_photo(ADMIN_CHAT_ID, message.photo[-1].file_id,
                   caption=f"📥 <b>Naya Payment</b>\n👤 User ID: <code>{uid}</code>\n📌 Plan: {p['name']} (₹{p['price']})",
                   reply_markup=kb)

if __name__ == "__main__":
    print("Bot chalu hai...")
    bot.infinity_polling()
