OMKAR INDIAN ARMY - फ़ाइलें
================================

index.html           आपकी वेबसाइट (वही फ़ाइल, बिना बदलाव) - पासवर्ड/लिंक सब वैसे ही
bot.py               Telegram bot (Railway पर चलेगा)
requirements.txt     bot के लिए packages
Procfile             Railway को बताता है कि bot कैसे चलाना है
change_passwords.py  नए पासवर्ड बनाकर index.html में बदल देता है

पासवर्ड (index.html और bot.py में एक जैसे)
  1 Month   : PASS_1MONTH_123
  3 Months  : PASS_3MONTH_456
  Lifetime  : PASS_LIFETIME_789

Railway पर चलाने के स्टेप
  1. bot.py, requirements.txt, Procfile को GitHub repository में डालें
  2. railway.app -> New Project -> Deploy from GitHub repo
  3. Variables में डालें:  BOT_TOKEN = (BotFather से मिला नया token)
     (ADMIN_CHAT_ID और UPI_ID पहले से bot.py में हैं)
  4. Deploy करें, फिर Telegram में /start भेजकर जाँचें

पासवर्ड बदलना हो (हर 30 दिन में, खुद चलाना पड़ेगा)
  python change_passwords.py
  -> index.html अपने आप बदल जाएगी
  -> जो 3 लाइनें दिखें उन्हें Railway Variables में डालें
  -> नई index.html वेबसाइट पर दोबारा अपलोड करें

सुरक्षा
  * BOT_TOKEN कभी भी फ़ाइल या चैट में न लिखें, सिर्फ Railway Variables में रखें।
  * पुराना token लीक हो चुका है तो @BotFather -> /revoke करके नया लें।
  * index.html में पासवर्ड लिखे हैं, इसलिए कोई "View Source" से देख सकता है।
